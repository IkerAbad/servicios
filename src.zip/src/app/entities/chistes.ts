export class Chistes {
    constructor(
        public category: string='',
        public type: string ='',
        public setup:string='',
        public delivery:string='') 
        {}
}
