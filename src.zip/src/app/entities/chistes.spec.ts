import { Chistes } from './chistes';

describe('Chistes', () => {
  it('should create an instance', () => {
    expect(new Chistes()).toBeTruthy();
  });
});
